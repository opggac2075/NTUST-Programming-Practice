#include <stdio.h>


int main(){
	printf("A human being is part of a whole called by us \"Universe.\"");
}
